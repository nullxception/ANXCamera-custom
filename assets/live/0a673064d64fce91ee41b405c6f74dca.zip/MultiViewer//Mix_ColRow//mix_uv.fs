precision mediump float;
varying vec2      textureCoords;
uniform sampler2D source0Sampler;
uniform sampler2D source1Sampler;
uniform sampler2D uvTextureSampler;

uniform float uOffset; // uv animation
uniform float vOffset;
uniform float uvColumnNum;
uniform float uvRowNum;

void main()
{

    float uOffsetStep = 1.0 / uvColumnNum;
    float vOffsetStep = 1.0 / uvRowNum;

    vec2 processedTextureCoords = textureCoords;
    processedTextureCoords = vec2(textureCoords.x / uvColumnNum + uOffsetStep * uOffset,
                                  textureCoords.y / uvRowNum + vOffsetStep * vOffset);

    vec4 uvColor = texture2D( uvTextureSampler, processedTextureCoords );

    bool isRed = uvColor.r > uvColor.g;

    if (uvColor.a == 1.0) {
        if (isRed) {
            gl_FragColor = texture2D(source0Sampler, textureCoords);
        } else {
            gl_FragColor = texture2D(source1Sampler, textureCoords);
        }
    } else {
        if (isRed) {
            gl_FragColor =  vec4(vec3(1.0) * (1.0 - uvColor.a) + texture2D(source0Sampler, textureCoords).rgb * uvColor.a, 1.0);
        } else if (uvColor.g > 0.01) {
            gl_FragColor =  vec4(vec3(1.0) * (1.0 - uvColor.a) + texture2D(source1Sampler, textureCoords).rgb * uvColor.a, 1.0);
        } else {
            gl_FragColor = vec4(1.0);
        }
    }
}